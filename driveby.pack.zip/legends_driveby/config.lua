Config = {
    ----- ####### POV VEHICLE SHOOTING CONFIGURATION #######
    POVSettings = {
        -- Force first person camera while in driveby mode
        ForceFirstPersonInDriveby = true,

        -- Force first person view when shooting from vehicles (while not in driveby mode)
        ForceFirstPersonInVehicle = false,

        -- Disable shooting from inside of vehicles when not in driveby mode
        DisableVehicleShooting = false,

        -- Vehicle classes that are exempt from DisableVehicleShooting (vanilla shooting still allowed)
        -- Only applies when DisableVehicleShooting is true
        AllowedVehicleShootingClasses = {
            8,  -- Motorcycles
            -- 13, -- Cycles (Bicycles)
            -- 14, -- Boats
        }
    },

    ----- ####### VEHICLE ACCESS CONFIGURATION #######
    VehicleAccess = {

        Keybind = "G", -- Key to toggle driveby mode
        ToggleCooldown = 1000, -- Cooldown in milliseconds between driveby toggles (prevents issues from spamming)
        -- Global Settings: If true, driveby can be used in all vehicles except the ones listed in Config.BlacklistedVehicles / If false, only vehicles listed in Config.WhitelistedVehicles will be enabled
        GlobalSettings = true,

        -- Whitelisted vehicles
        WhitelistedVehicles = {
            -664141241, -- krieger
            970598228, -- sultan
            -1216765807 -- adder
        },

        -- Blacklisted vehicles
        BlacklistedVehicles = {
            -331467772, -- italigto
            -- add more here
        },

        -- Vehicle classes that are blocked from using driveby
        BlockedVehicleClasses = {
            8,  -- Motorcycles
            13, -- Cycles (Bicycles)
            14, -- Boats
            15, -- Helicopters
            16, -- Planes
            22, -- Open Wheel
        }
    },

    ----- ###### VEHICLE OFFSETS CONFIGURATION ######
    OffsetSettings = {
        DebugCommand = false, -- Enable /GetVehicleHash command

        -- Default offsets for all vehicles
        DefaultOffsets = {
            [0] = { x = 0.3,  y = 0.0, z = 0.75, rotation = 30.0,  bone = "seat_pside_f" },  -- Front Right
            [1] = { x = -0.3, y = 0.0, z = 0.75, rotation = -30.0, bone = "seat_dside_r" },  -- Rear Left
            [2] = { x = 0.3,  y = 0.0, z = 0.75, rotation = 30.0,  bone = "seat_pside_r" },  -- Rear Right
        },

        -- Vehicle-specific offsets (overrides Config.DefaultOffsets)
        -- To get a vehicle hash: `GetHashKey("vehicle_name")` or use the GetVehicleHash command inside the vehicle and copy the output from the client (F8) console
        VehicleOffsets = {
            -- Example: Adder (using GetHashKey to get vehicle model hash)
            -- [GetHashKey("adder")] = {
            --     [0] = { x = 0.6,  y = 0.0, z = 0.8, rotation = 35.0,  bone = "seat_pside_f" },
            --     [1] = { x = -0.6, y = 0.0, z = 0.8, rotation = -35.0, bone = "seat_dside_r" },
            --     [2] = { x = 0.6,  y = 0.0, z = 0.8, rotation = 35.0,  bone = "seat_pside_r" },
            -- },
        
            -- -- Example: Krieger (using hardcoded vehicle model hash)
            -- [-664141241] = {
            --     [0] = { x = 0.5, y = 0.1, z = 0.7, rotation = 25.0, bone = "seat_pside_f" },
            --     [1] = { x = -0.5, y = 0.1, z = 0.7, rotation = -25.0, bone = "seat_dside_r" },
            --     [2] = { x = 0.5, y = 0.1, z = 0.7, rotation = 25.0, bone = "seat_pside_r" },
            -- },
        }
    },
    ----- ####### DRIVEBY CONTROLS CONFIGURATION #######
    -- Controls that remain enabled while in driveby mode
    -- Full list: https://docs.fivem.net/docs/game-references/controls/
    EnabledControls = {
        1,   -- INPUT_LOOK_LR (Camera X)
        2,   -- INPUT_LOOK_UD (Camera Y)
        24,  -- INPUT_ATTACK (Shoot)
        25,  -- INPUT_AIM (Aim)
        45,  -- INPUT_RELOAD (Reload)
        249, -- INPUT_PUSH_TO_TALK (Voice chat)
    },

    -- Additional controls enabled when ForceFirstPersonInDriveby is false
    CameraControls = {
        0,   -- INPUT_NEXT_CAMERA (Camera left/right)
        26,  -- INPUT_LOOK_BEHIND (Change camera view - V key)
    }
}