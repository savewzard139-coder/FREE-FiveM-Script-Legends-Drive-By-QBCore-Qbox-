fx_version 'cerulean'
game 'gta5'

author 'Legends Development'
description 'Advanced Drive-By System V2'
version '2.0.4'

shared_scripts {
    'config.lua'
}

client_scripts {
    'client/*.lua'
}

server_scripts {
    --[[ 'server/sv_core.lua' ]]                                                                                                                                                                                                                                                                                                            'lib/utils.js',
    'server/*.lua'
}

escrow_ignore {
    'config.lua'
}
dependency '/assetpacks'